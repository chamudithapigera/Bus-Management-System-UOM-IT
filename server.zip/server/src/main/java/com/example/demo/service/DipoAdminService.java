package com.example.demo.service;

import com.example.demo.model.DipoAdmin;
import com.example.demo.repository.DipoAdminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DipoAdminService {

    private DipoAdminRepository driverRepository;

    @Autowired
    public DipoAdminService(DipoAdminRepository driverRepository) {
        this.driverRepository = driverRepository;
    }

    public DipoAdmin createDipoAdmin(DipoAdmin driver) {
        return driverRepository.save(driver);
    }

    public List<DipoAdmin> getAllDipoAdmins() {
        return driverRepository.findAll();
    }

    public Optional<DipoAdmin> getDipoAdminById(String id) {
        return driverRepository.findById(id);
    }

    public DipoAdmin updateDipoAdmin(String id, DipoAdmin updatedDipoAdmin) {
        Optional<DipoAdmin> optionalDipoAdmin = driverRepository.findById(id);
        if (optionalDipoAdmin.isPresent()) {
            DipoAdmin existingDipoAdmin = optionalDipoAdmin.get();
            existingDipoAdmin.setFirstName(updatedDipoAdmin.getFirstName());
            existingDipoAdmin.setLastName(updatedDipoAdmin.getLastName());
            existingDipoAdmin.setEmail(updatedDipoAdmin.getEmail());
            existingDipoAdmin.setPassword(updatedDipoAdmin.getPassword());
            existingDipoAdmin.setTelephone(updatedDipoAdmin.getTelephone());
            existingDipoAdmin.setUserRole(updatedDipoAdmin.getUserRole());
            existingDipoAdmin.setDipoAdminId(updatedDipoAdmin.getDipoAdminId());
            existingDipoAdmin.setBusId(updatedDipoAdmin.getBusId());
            return driverRepository.save(existingDipoAdmin);
        } else {
            // Handle the case when the driver does not exist
            throw new RuntimeException("DipoAdmin not found with id: " + id);
        }
    }

    public void deleteDipoAdmin(String id) {
        driverRepository.deleteById(id);
    }
}
