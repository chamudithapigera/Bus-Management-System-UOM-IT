package com.example.demo.controller;

import com.example.demo.model.DipoAdmin;
import com.example.demo.repository.DipoAdminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/dipoadmin")
public class DipoAdminController {

    @Autowired
    private DipoAdminRepository driverRepository;

    @PostMapping
    public ResponseEntity<DipoAdmin> createDipoAdmin(@RequestBody DipoAdmin driver) {
        DipoAdmin savedDipoAdmin = driverRepository.save(driver);
        return new ResponseEntity<>(savedDipoAdmin, HttpStatus.OK);
    }

    @GetMapping
    public List<DipoAdmin> getAllDipoAdmins() {
        return driverRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<DipoAdmin> getDipoAdminById(@PathVariable("id") String id) {
        Optional<DipoAdmin> optionalDipoAdmin = driverRepository.findById(id);
        return optionalDipoAdmin.map(driver -> new ResponseEntity<>(driver, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDipoAdmin(@PathVariable("id") String id) {
        System.out.println("Delete driver request received for ID: " + id);

        Optional<DipoAdmin> optionalDipoAdmin = driverRepository.findById(id);
        if (optionalDipoAdmin.isPresent()) {
            driverRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}

//all the control parts like deletemapping, get mapping, postmapping. data pass via frontend and database.