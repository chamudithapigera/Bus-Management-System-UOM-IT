package com.example.demo.repository;

import com.example.demo.model.DipoAdmin;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface DipoAdminRepository extends MongoRepository<DipoAdmin, String> {
}


//database access the data