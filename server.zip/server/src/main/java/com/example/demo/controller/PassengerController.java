package com.example.demo.controller;

import com.example.demo.model.Passenger;
import com.example.demo.repository.PassengerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/passenger")
public class PassengerController {

    @Autowired
    private PassengerRepository driverRepository;

    @PostMapping
    public ResponseEntity<Passenger> createPassenger(@RequestBody Passenger driver) {
        Passenger savedPassenger = driverRepository.save(driver);
        return new ResponseEntity<>(savedPassenger, HttpStatus.OK);
    }

    @GetMapping
    public List<Passenger> getAllPassengers() {
        return driverRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Passenger> getPassengerById(@PathVariable("id") String id) {
        Optional<Passenger> optionalPassenger = driverRepository.findById(id);
        return optionalPassenger.map(driver -> new ResponseEntity<>(driver, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePassenger(@PathVariable("id") String id) {
        System.out.println("Delete driver request received for ID: " + id);

        Optional<Passenger> optionalPassenger = driverRepository.findById(id);
        if (optionalPassenger.isPresent()) {
            driverRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
