package com.example.demo.service;

import com.example.demo.model.Passenger;
import com.example.demo.repository.PassengerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PassengerService {

    private PassengerRepository driverRepository;

    @Autowired
    public PassengerService(PassengerRepository driverRepository) {
        this.driverRepository = driverRepository;
    }

    public Passenger createPassenger(Passenger driver) {
        return driverRepository.save(driver);
    }

    public List<Passenger> getAllPassengers() {
        return driverRepository.findAll();
    }

    public Optional<Passenger> getPassengerById(String id) {
        return driverRepository.findById(id);
    }

    public Passenger updatePassenger(String id, Passenger updatedPassenger) {
        Optional<Passenger> optionalPassenger = driverRepository.findById(id);
        if (optionalPassenger.isPresent()) {
            Passenger existingPassenger = optionalPassenger.get();
            existingPassenger.setFirstName(updatedPassenger.getFirstName());
            existingPassenger.setLastName(updatedPassenger.getLastName());
            existingPassenger.setEmail(updatedPassenger.getEmail());
            existingPassenger.setPassword(updatedPassenger.getPassword());
            existingPassenger.setTelephone(updatedPassenger.getTelephone());
            existingPassenger.setUserRole(updatedPassenger.getUserRole());
            existingPassenger.setPassengerId(updatedPassenger.getPassengerId());
            existingPassenger.setBusId(updatedPassenger.getBusId());
            return driverRepository.save(existingPassenger);
        } else {
            // Handle the case when the driver does not exist
            throw new RuntimeException("Passenger not found with id: " + id);
        }
    }

    public void deletePassenger(String id) {
        driverRepository.deleteById(id);
    }
}
