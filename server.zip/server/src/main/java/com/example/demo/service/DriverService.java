package com.example.demo.service;

import com.example.demo.model.Driver;
import com.example.demo.repository.DriverRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DriverService {

    private DriverRepository driverRepository;

    @Autowired
    public DriverService(DriverRepository driverRepository) {
        this.driverRepository = driverRepository;
    }

    public Driver createDriver(Driver driver) {
        return driverRepository.save(driver);
    }

    public List<Driver> getAllDrivers() {
        return driverRepository.findAll();
    }

    public Optional<Driver> getDriverById(String id) {
        return driverRepository.findById(id);
    }

    public Driver updateDriver(String id, Driver updatedDriver) {
        Optional<Driver> optionalDriver = driverRepository.findById(id);
        if (optionalDriver.isPresent()) {
            Driver existingDriver = optionalDriver.get();
            existingDriver.setFirstName(updatedDriver.getFirstName());
            existingDriver.setLastName(updatedDriver.getLastName());
            existingDriver.setEmail(updatedDriver.getEmail());
            existingDriver.setPassword(updatedDriver.getPassword());
            existingDriver.setTelephone(updatedDriver.getTelephone());
            existingDriver.setUserRole(updatedDriver.getUserRole());
            existingDriver.setDriverId(updatedDriver.getDriverId());
            existingDriver.setBusId(updatedDriver.getBusId());
            return driverRepository.save(existingDriver);
        } else {
            // Handle the case when the driver does not exist
            throw new RuntimeException("Driver not found with id: " + id);
        }
    }

    public void deleteDriver(String id) {
        driverRepository.deleteById(id);
    }
}
