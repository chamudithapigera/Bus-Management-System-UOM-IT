import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { useSelector } from "react-redux";

import { Input, Button } from "../../../components/ui";

const Chat = () => {
    const { partnerId } = useParams();

    const inputDataStructure = {
        message: {
            key: "message",
            label: "",
            placeholder: "Type message",
            data: "",
            type: "text",
            error: null,
        },
    };

    const token = useSelector((state) => state.user.token);

    const [inputs, setInputs] = useState(inputDataStructure);
    const [messages, setMessages] = useState(null);
    const [chats, setChats] = useState([]);

    const handleChange = (data, input) => {
        input.data = data;

        let input_list = { ...inputs };
        input_list[input.key] = input;
        setInputs(input_list);
    };

    const refreshData = async () => {
        try {
            // const chats = await getChatsByUser(token);
            // setChats(chats);
        } catch (e) {
            console.log(e);
        }
    };

    useEffect(() => {
        refreshData();
        const intervalId = setInterval(refreshData, 10000);

        return () => clearInterval(intervalId);
    }, []);

    const handleSend = async () => {
        const data = {
            partnerId: partnerId,
            message: inputs.message.data,
        };
        try {
            //await sendMessage(data, token);
            refreshData();
        } catch (e) {
            console.log(e);
        }
    };

    return (
        <section className="w-full">
            <div className="grid grid-cols-3 gap-3 bg-white px-2 py-2 mb-3 rounded-md">
                <div className="col-span-2">
                    {messages && (
                        <div>
                            <div className="space-y-2 mb-4">
                                {messages.map((message) => {
                                    if (message.sentBy === partnerId) {
                                        return (
                                            <div
                                                className="flex justify-end"
                                                key={message.id}
                                            >
                                                <p className="bg-gray-200 rounded-lg py-2 px-4 text-sm text-gray-700">
                                                    {message.message}
                                                </p>
                                            </div>
                                        );
                                    } else {
                                        return (
                                            <div
                                                className="flex justify-start"
                                                key={message.id}
                                            >
                                                <p className="bg-blue-500 rounded-lg py-2 px-4 text-sm text-white">
                                                    {message.text}
                                                </p>
                                            </div>
                                        );
                                    }
                                })}
                            </div>
                            <Input
                                input={inputs.message}
                                handleChange={handleChange}
                            />
                            <Button text={"Send"} handleClick={handleSend} />
                        </div>
                    )}
                    <div className="text-center mt-4 text-gray-600">
                        {!messages && (
                            <div className="bg-gray-100 p-4 rounded-lg">
                                Please select a chat to start messaging.
                            </div>
                        )}
                    </div>
                </div>

                <div className="bg-gray-100 p-4">
                    <h2 className="text-xl font-semibold mb-4">Chat List</h2>
                    {chats.map((chat) => (
                        <a
                            href={"/profile/chat/" + chat.id}
                            key={chat._id}
                            className="flex items-center p-2 hover:bg-gray-200 cursor-pointer"
                        >
                            <img
                                src={require("../../../assets/img/profile.png")} // Replace with the profile picture URL
                                alt={chat.name}
                                className="w-10 h-10 rounded-full mr-4"
                            />
                            <p className="text-lg text-gray-800">{chat.name}</p>
                        </a>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Chat;
