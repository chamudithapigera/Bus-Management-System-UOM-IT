import React from "react";
import {
    LineChart,
    Line,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    Legend,
    ResponsiveContainer,
} from "recharts";

const ChartSection = () => {
    const data = [
        { name: "January",Passengers: 0, Drivers: 4, DepoAdmins: 5},
        { name: "February", Passengers: 15, Drivers: 2, DepoAdmins: 3},
        { name: "March", Passengers: 10, Drivers: 19, DepoAdmins: 18},
        { name: "April", Passengers: 13, Drivers: 7, DepoAdmins: 9},
        { name: "May", Passengers: 9, Drivers: 9, DepoAdmins: 10},
        { name: "June", Passengers: 11, Drivers: 7, DepoAdmins: 10},
        { name: "July", Passengers: 17, Drivers: 8, DepoAdmins: 6},
        { name: "Augest", Passengers: 17, Drivers: 8, DepoAdmins: 8},
        { name: "September", Passengers: 20, Drivers: 4, DepoAdmins: 6},
        { name: "October", Passengers: 15, Drivers: 4, DepoAdmins: 9},
        { name: "November", Passengers: 10, Drivers: 8, DepoAdmins: 11},
        { name: "December", Passengers: 17, Drivers: 10, DepoAdmins: 12},
    ];
    return (
        <ResponsiveContainer width="99%" height={400}>
            <LineChart
                data={data}
                margin={{
                    top: 5,
                    right: 30,
                    left: 20,
                    bottom: 5,
                }}
            >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line
                    type="monotone"
                    dataKey="Passengers"
                    stroke="#326ba8"
                    activeDot={{ r: 8 }}
                />
                <Line type="monotone" dataKey="Drivers" stroke="#ba382d" />
                <Line type="monotone" dataKey="DepoAdmins" stroke="#0F9B79" />

            </LineChart>
        </ResponsiveContainer>
    );
};

export default ChartSection;