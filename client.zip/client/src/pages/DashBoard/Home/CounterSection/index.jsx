import React from "react";
import { FaUsers, FaUser, FaCheckDouble } from "react-icons/fa";

import SingleCounter from "./SingleCounter";

const CounterSection = ({ countData }) => {
    const counts = [
        { title: "Total busses", count: 12, icon: <FaUsers /> },
        {
            title: "Total drivers",
            count: 4,
            icon: <FaUser />,
        },
        {
            title: "Total depo admins",
            count: 6,
            icon: <FaCheckDouble />,
        },
        { title: "Total passengers", count: 48, icon: <FaUsers /> },
        {
            title: "Total turns",
            count: 4,
            icon: <FaUser />,
        },
        {
            title: "Total breakdowns",
            count: 8,
            icon: <FaCheckDouble />,
        },
    ];

    return (
        <div className="flex flex-wrap">
            {counts.map((item) => {
                return <SingleCounter item={item} />;
            })}
        </div>
    );
};

export default CounterSection;
