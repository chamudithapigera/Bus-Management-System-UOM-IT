import React, { useState } from "react";
import ChartSection from "./ChartSection";
import CounterSection from "./CounterSection";

const Home = () => {
    const [countData, setCounts] = useState([]);

    return (
        <div>
            <CounterSection countData={countData} />
            <ChartSection />
        </div>
    );
};

export default Home;
