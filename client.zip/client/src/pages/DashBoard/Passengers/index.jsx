import React, { useEffect, useState } from "react";
import { Table } from "antd";
import { toast } from "react-toastify";

import { getPasengers, deletePasenger } from "../../../http/passenger";
import PasengerModal from "./driverModal";

import { Input, Select, Button, Confirm } from "../../../components/ui";

import { FaEdit } from "react-icons/fa";
import { MdDelete } from "react-icons/md";

const CustomerList = () => {
    const [drivers, setPasengers] = useState([]);
    const [dataModalState, setDataModalState] = useState(false);
    const [confirmModalState, setConfirmModalState] = useState(false);
    const [selectedPasenger, setSelectedPasenger] = useState(null);

    const handleDelete = async () => {
        console.log(selectedPasenger);
        try {
            await deletePasenger(selectedPasenger.id);
            setConfirmModalState(false);
            refreshPasengers();
            toast.success("Pasenger deleted successfully");
        } catch (e) {}
    };

    const handleCloseModal = () => {
        refreshPasengers();
        setDataModalState(false);
        setConfirmModalState(false);
        setSelectedPasenger(null);
    };

    const refreshPasengers = () => {
        try {
            getPasengers(drivers).then((data) => {
                setPasengers(data);
            });
        } catch (e) {
            console.log(e);
        }
    };

    useEffect(() => {
        refreshPasengers();
        const intervalId = setInterval(refreshPasengers, 10000);

        return () => clearInterval(intervalId);
    }, []);

    const stock_status = (count) => {
        let classes =
            "inline-flex items-center justify-center px-2  py-1 mr-2 text-xs font-bold leading-none text-red-100 rounded-full";
        classes += count ? " bg-green-500" : " bg-red-500";

        return (
            <div>
                <span className={classes}>{count}</span>
            </div>
        );
    };

    const actionBtns = (driver) => {
        return (
            <div className="flex">
                <a
                    className="pointer hover:bg-gray-100 hover:text-gray-70"
                    onClick={() => {
                        setSelectedPasenger(driver);
                        setConfirmModalState(true);
                    }}
                >
                    <MdDelete />
                </a>
            </div>
        );
    };
    const img = (avatar) => {
        return (
            <div className="flex">
                <img
                    className="w-11 h-11 p-1 rounded-full ring-2 ring-gray-300 dark:ring-gray-500"
                    src={require("../../../assets/img/profile.png")}
                />
            </div>
        );
    };

    const columns = [
        {
            title: "Image",
            dataIndex: "",
            key: "avatar",
            render: (arg) => img(arg.avatar),
        },
        {
            title: "First Name",
            dataIndex: "firstName",
            key: "firstName",
            align: "center",
            width: "40%",
            sorter: (a, b) => a.firstName.localeCompare(b.firstName),
        },
        {
            title: "Last Name",
            dataIndex: "lastName",
            key: "lastName",
            align: "center",
            width: "40%",
            sorter: (a, b) => a.lastName.localeCompare(b.lastName),
        },
        {
            title: "Email",
            dataIndex: "email",
            key: "email",
            align: "center",
            width: "10%",
        },
        {
            title: "Telephone",
            dataIndex: "telephone",
            key: "telephone",
            align: "center",
            width: "40%",
        },

        {
            title: "Operations",
            dataIndex: "",
            key: "operations",
            align: "center",
            width: "20%",
            render: (arg) => actionBtns(arg),
        },
    ];

    return (
        <section className="w-full">
            {dataModalState && (
                <PasengerModal
                    handleClose={handleCloseModal}
                    selectedPasenger={selectedPasenger}
                />
            )}
            {confirmModalState && (
                <Confirm
                    cancelHandler={handleCloseModal}
                    confirmHandler={handleDelete}
                />
            )}
            <div className="grid grid-cols-3 gap-3 bg-white px-2 py-2 mb-3 rounded-md">
                <div>
                    <Button
                        text={"Add new"}
                        handleClick={() => setDataModalState(true)}
                    />
                </div>
            </div>
            <Table columns={columns} dataSource={drivers} />
        </section>
    );
};

export default CustomerList;
