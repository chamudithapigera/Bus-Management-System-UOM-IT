import React from "react";
import NavBar from "../../components/admin/NavBar";
import SideBar from "../../components/admin/SideBar";

import HomeSection from "./Home";
import PassengerSection from "./Passengers";
import DriverSection from "./Drivers";
import DipoAdminSection from "./DipoAdmins";
import BreakdownSection from "./Breakdown";
import SettingSection from "./Settings";
import ChatSection from "./Chat";

const Dashboard = ({ section }) => {
    return (
        <div>
            <NavBar />
            <div className="flex mt-[85px] gap-6">
                <div className="w-[220px] p-10 bg-primary fixed h-screen -mt-12">
                    <SideBar section={section} />
                </div>
                <div className="w-full ml-[220px] ">
                    {section === "home" && <HomeSection />}
                    {section === "passengers" && <PassengerSection />}
                    {section === "drivers" && <DriverSection />}
                    {section === "dipo-admin" && <DipoAdminSection />}
                    {section === "breakdown" && <BreakdownSection />}
                    {section === "settings" && <SettingSection />}
                    {section === "chat" && <ChatSection />}
                </div>
            </div>
        </div>
    );
};

export default Dashboard;
