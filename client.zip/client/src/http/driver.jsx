import Axios from "axios";
import { host } from "./host";

export const getDrivers = () => {
    return new Promise((resolve, reject) => {
        Axios.get(host + "driver")
            .then((response) => {
                if (response.status == 200) {
                    return resolve(response.data);
                }
            })
            .catch((e) => {
                return reject(e.response.data.message);
            });
    });
};

export const createDriver = (data) => {
    return new Promise((resolve, reject) => {
        Axios.post(host + "driver", data)
            .then((response) => {
                if (response.status == 200) {
                    return resolve(response.data);
                }
            })
            .catch((e) => {
                console.log(e.request);
                return reject(e.response.data.message);
            });
    });
};

export const deleteDriver = (id) => {
    return new Promise((resolve, reject) => {
        Axios.delete(host + "driver/" + id)
            .then((response) => {
                if (response.status == 200) {
                    return resolve(response.data);
                }
            })
            .catch((e) => {
                return reject(e.response.data.message);
            });
    });
};
