export const host = "http://localhost:8080/api/";
