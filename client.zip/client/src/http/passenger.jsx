import Axios from "axios";
import { host } from "./host";

export const login = (data) => {
    return new Promise((resolve, reject) => {
        Axios.post(host + "passenger/login", data)
            .then((response) => {
                if (response.status == 200) {
                    return resolve(response.data);
                }
            })
            .catch((e) => {
                return reject(e.response.data.message);
            });
    });
};

export const registerStageOne = (data) => {
    return new Promise((resolve, reject) => {
        Axios.post(host + "passenger/register/stage/1", data)
            .then((response) => {
                if (response.status == 200) {
                    return resolve(response.data);
                }
            })
            .catch((e) => {
                return reject(e.response.data.message);
            });
    });
};

export const registerStageTwo = (data) => {
    return new Promise((resolve, reject) => {
        Axios.post(host + "passenger/register/stage/2", data)
            .then((response) => {
                if (response.status == 200) {
                    return resolve(response.data);
                }
            })
            .catch((e) => {
                return reject(e.response.data.message);
            });
    });
};

export const registerStageThree = (data) => {
    return new Promise((resolve, reject) => {
        Axios.post(host + "passenger/register/stage/3", data)
            .then((response) => {
                if (response.status == 200) {
                    return resolve(response.data);
                }
            })
            .catch((e) => {
                return reject(e.response.data.message);
            });
    });
};
export const resetStageOne = (data) => {
    return new Promise((resolve, reject) => {
        Axios.post(host + "passenger/reset/stage/1", data)
            .then((response) => {
                if (response.status == 200) {
                    return resolve(response.data);
                }
            })
            .catch((e) => {
                return reject(e.response.data.message);
            });
    });
};

export const resetStageTwo = (data) => {
    return new Promise((resolve, reject) => {
        Axios.post(host + "passenger/reset/stage/2", data)
            .then((response) => {
                if (response.status == 200) {
                    return resolve(response.data);
                }
            })
            .catch((e) => {
                return reject(e.response.data.message);
            });
    });
};

export const resetStageThree = (data) => {
    return new Promise((resolve, reject) => {
        Axios.post(host + "passenger/reset/stage/3", data)
            .then((response) => {
                if (response.status == 200) {
                    return resolve(response.data);
                }
            })
            .catch((e) => {
                return reject(e.response.data.message);
            });
    });
};

export const getPasengers = () => {
    return new Promise((resolve, reject) => {
        Axios.get(host + "passenger")
            .then((response) => {
                if (response.status == 200) {
                    return resolve(response.data);
                }
            })
            .catch((e) => {
                return reject(e.response.data.message);
            });
    });
};

export const getpasenger = (id) => {
    return new Promise((resolve, reject) => {
        Axios.get(host + "passenger/" + id)
            .then((response) => {
                if (response.status == 200) {
                    return resolve(response.data);
                }
            })
            .catch((e) => {
                return reject(e.response.data.message);
            });
    });
};

export const createPasenger = (data) => {
    const config = {
        hedoctorers: {
            "Content-Type": "multipart/form-data",
        },
    };
    return new Promise((resolve, reject) => {
        Axios.post(host + "passenger", data, config)
            .then((response) => {
                if (response.status == 200) {
                    return resolve(response.data);
                }
            })
            .catch((e) => {
                console.log(e.request);
                return reject(e.response.data.message);
            });
    });
};

export const updatePasenger = (data) => {
    const config = {
        hedoctorers: {
            "Content-Type": "multipart/form-data",
        },
    };
    return new Promise((resolve, reject) => {
        Axios.patch(host + "passenger", data, config)
            .then((response) => {
                if (response.status == 200) {
                    return resolve(response.data);
                }
            })
            .catch((e) => {
                return reject(e.response.data.message);
            });
    });
};

export const updateProfile = (data) => {
    return new Promise((resolve, reject) => {
        Axios.patch(host + "passenger/profile", data)
            .then((response) => {
                if (response.status == 200) {
                    return resolve(response.data);
                }
            })
            .catch((e) => {
                return reject(e.response.data.message);
            });
    });
};
export const updatePassword = (data) => {
    return new Promise((resolve, reject) => {
        Axios.patch(host + "passenger/password", data)
            .then((response) => {
                if (response.status == 200) {
                    return resolve(response.data);
                }
            })
            .catch((e) => {
                return reject(e.response.data.message);
            });
    });
};

export const deletePasenger = (id) => {
    return new Promise((resolve, reject) => {
        Axios.delete(host + "passenger/" + id)
            .then((response) => {
                if (response.status == 200) {
                    return resolve(response.data);
                }
            })
            .catch((e) => {
                return reject(e.response.data.message);
            });
    });
};
