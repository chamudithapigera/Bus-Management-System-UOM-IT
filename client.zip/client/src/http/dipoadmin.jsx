import Axios from "axios";
import { host } from "./host";

export const getDipoAdmins = () => {
    return new Promise((resolve, reject) => {
        Axios.get(host + "dipoadmin")
            .then((response) => {
                if (response.status == 200) {
                    return resolve(response.data);
                }
            })
            .catch((e) => {
                return reject(e.response.data.message);
            });
    });
};

export const createDipoAdmin = (data) => {
    return new Promise((resolve, reject) => {
        Axios.post(host + "dipoadmin", data)
            .then((response) => {
                if (response.status == 200) {
                    return resolve(response.data);
                }
            })
            .catch((e) => {
                console.log(e.request);
                return reject(e.response.data.message);
            });
    });
};

export const deleteDipoAdmin = (id) => {
    return new Promise((resolve, reject) => {
        Axios.delete(host + "dipoadmin/" + id)
            .then((response) => {
                if (response.status == 200) {
                    return resolve(response.data);
                }
            })
            .catch((e) => {
                return reject(e.response.data.message);
            });
    });
};
