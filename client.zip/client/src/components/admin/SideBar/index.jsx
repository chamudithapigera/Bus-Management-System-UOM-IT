import React from "react";

import ListItem from "./listItem";

import {
    
    FaUsers,
    FaHome,
    FaPowerOff,
    
} from "react-icons/fa";

const SideBar = ({ section }) => {
    const navList = [
        {
            id: 1,
            title: "Home",
            url: "/",
            icon: <FaHome />,
            selected: section === "home",
        },

        {
            id: 4,
            title: "Passengers",
            url: "/passengers",
            icon: <FaUsers />,
            selected: section === "passengers",
        },
        {
            id: 4,
            title: "Drivers",
            url: "/drivers",
            icon: <FaUsers />,
            selected: section === "drivers",
        },
        {
            id: 4,
            title: "Dipo Admins",
            url: "/dipo-admin",
            icon: <FaUsers />,
            selected: section === "dipo-admin",
        },
        {
            id: 5,
            title: "Notification",
            url: "/breakdown",
            icon: <FaUsers />,
            selected: section === "breakdown",
        },
        {
            id: 5,
            title: "Chat",
            url: "/chat",
            icon: <FaUsers />,
            selected: section === "chat",
        },

        {
            id: 7,
            title: "Settings",
            url: "/settings",
            icon: <FaPowerOff />,
            selected: section === "settings",
        },
        {
            id: 7,
            title: "Logout",
            url: "/logout",
            icon: <FaPowerOff />,
        },
    ];

    return (
        <ul className="space-y-4 mb-12 mt-8 w-full">
            {navList.map((item) => (
                <ListItem key={item.id} item={item} />
            ))}
        </ul>
    );
};
export default SideBar;
