import React from "react";
import { Routes, Route, Navigate, Outlet } from "react-router-dom";
import { useSelector } from "react-redux";

import { Logout, Login, Dashboard } from "../pages";

const AdminRoutes = () => {
    const PrivateRouter = () => {
        const user = useSelector((state) => state.user);

        if (user.authenticated) {
            return <Outlet />;
        } else {
            return <Navigate to="/login" />;
        }
    };

    return (
        <Routes>
            <Route path="/login" element={<Login />} />

            <Route element={<PrivateRouter />}>
                <Route path="" element={<Dashboard section={"home"} />} />
                <Route
                    path="/attendence"
                    element={<Dashboard section={"attendence"} />}
                />
                <Route
                    path="/passengers"
                    element={<Dashboard section={"passengers"} />}
                />
                <Route
                    path="/drivers"
                    element={<Dashboard section={"drivers"} />}
                />
                <Route
                    path="/dipo-admin"
                    element={<Dashboard section={"dipo-admin"} />}
                />
                <Route path="/map" element={<Dashboard section={"map"} />} />
                <Route path="/chat" element={<Dashboard section={"chat"} />} />
                <Route
                    path="/breakdown"
                    element={<Dashboard section={"breakdown"} />}
                />
                <Route
                    path="/settings"
                    element={<Dashboard section={"settings"} />}
                />
                <Route path="/logout" element={<Logout />} />
            </Route>
        </Routes>
    );
};

export default AdminRoutes;
